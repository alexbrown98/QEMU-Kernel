/* Copyright (C) 2017 Daniel Page <csdsp@bristol.ac.uk>
 *
 * Use of this source code is restricted per the CC BY-NC-ND license, a copy of 
 * which can be found via http://creativecommons.org (and should be included as 
 * LICENSE.txt within the associated archive or repository).
 */

#include "hilevel.h"
#include <stdio.h>
#include <string.h>
#include "SP804.h"


// Initialise the process table
pcb_t procTab[ MAX_PROCS ]; pcb_t* executing = NULL;


pcb_t* make_child(pcb_t* parent, ctx_t* ctx) {
    pcb_t* child = NULL;
    for (int i = 0; i < MAX_PROCS; i++) {
        if (procTab[ i ].status == STATUS_TERMINATED) {
            child = &procTab[ i ];
            break;
        }
    }
    if (child == NULL) {return NULL;}

    uint32_t child_bos  = child->tos - STACK_SIZE;     // child  bottom of stack address
    uint32_t parent_bos = parent->tos - STACK_SIZE;    // parent bottom of stack address
    
    memcpy(&child->ctx, ctx, sizeof(ctx_t));       // copy parent context to child
    memcpy ((void *) child_bos, (void *) parent_bos, STACK_SIZE);             //clone parent stack
    uint32_t offset = parent->tos - (ctx->sp);              // calculate relative stack pointer position
    child->ctx.sp   = child->tos - offset;                    // set child stack pointer


    child->status = STATUS_CREATED;
    return child;

}


void dispatch (ctx_t* ctx, pcb_t* prev, pcb_t* next ) {
    char prev_pid = '?', next_pid = '?';
    if( NULL != prev ) {
      memcpy( &prev->ctx, ctx, sizeof( ctx_t ) ); // preserve execution context of P_{prev}
	    prev_pid = '0' + prev->pid;
      prev-> status = STATUS_READY;
      prev -> age = 0;
    }
    if( NULL != next ) {
      memcpy( ctx, &next->ctx, sizeof( ctx_t ) ); // restore  execution context of P_{next}
	    next_pid = '0' + next->pid;
      next->status = STATUS_EXECUTING;
    }

                            
	PL011_putc( UART0, '[',	true );
	PL011_putc( UART0, prev_pid,	true );
	PL011_putc( UART0, '-',	true );
	PL011_putc( UART0, '>',	true );
	PL011_putc( UART0, next_pid,	true );
	PL011_putc( UART0, ']',	true );

 	executing = next;    	// update   executing index   to P_{next}
    return;
}


void schedule( ctx_t* ctx ) {
  /* 
  Scheduling Algorithm: Calculate a "score" for each process, with the formula
    score = precedence + age
  To change the weighting of precedence and/or age, simply multiply the precedence or age variable by a constant
  */

	pcb_t* prev = NULL;
    pcb_t* next = NULL;
    int maxscore = 0;
	for (int i = 0; i < MAX_PROCS; i++) {                               // Find and set currenctly executing task to previous
		if (procTab[ i ].status == STATUS_EXECUTING) {
            prev = &procTab[ i ];
            break;
		}
    }
    bool task_available = false;
    for (int i = 0; i < MAX_PROCS; i++) {
        if (procTab[ i ].status == STATUS_READY || procTab[ i ].status == STATUS_CREATED) {           // Calculate a score for ready tasks and set the highest scoring task
            int score = procTab[ i ].precedence + procTab[ i ].age;   // to next
            if (score > maxscore) {
                maxscore = score;
                next = &procTab[ i ];
            }
            task_available = true;
        }
    }
    if (!task_available) {
        next = prev;
        next->age = 0;
        for (int i = 0; i < MAX_PROCS; i++) {
            if (procTab[ i ].pid != next->pid) {procTab[ i ].age++;}
        }
        dispatch(ctx, prev, next);
        return;
    }
    else {
        for (int i = 0; i < MAX_PROCS; i++) {                               // Set the age of the next task to 0, and increase the age of all
            if (procTab[ i ].pid == next->pid) {                      // other tasks by 1.
                procTab[ i ].age = 0;
            }
            else { procTab[ i ].age ++;}
        }
        dispatch(ctx,prev,next);
        return;
    }

}

extern void	main_console();
extern uint32_t tos_console;
extern uint32_t tos_procs;


void hilevel_handler_rst(ctx_t* ctx) {
    // Indicate that a reset is being handled
    PL011_putc( UART0, '[', true );
    PL011_putc( UART0, 'R', true );
    PL011_putc( UART0, 'E', true );
    PL011_putc( UART0, 'S', true );
    PL011_putc( UART0, 'E', true );
    PL011_putc( UART0, 'T', true );
    PL011_putc( UART0, ']', true );

    // Invalidate the entries in the process table
    for (int i = 0; i < MAX_PROCS; i++) {
        procTab[i].status = STATUS_INVALID;
    }
    
    memset( &procTab[ 0 ], 0, sizeof( pcb_t ) ); // initialise 0-th PCB = P_3
    procTab[ 0 ].pid      = 0;
    procTab[ 0 ].status   = STATUS_READY;
    procTab[ 0 ].tos      = ( uint32_t )( &tos_console  );
    procTab[ 0 ].ctx.cpsr = 0x50;
    procTab[ 0 ].ctx.pc   = ( uint32_t )( &main_console );
    procTab[ 0 ].ctx.sp   = procTab[ 0 ].tos;
    procTab[ 0 ].precedence = 2;
    procTab[ 0 ].age = 0;

   for (int i = 1; i < MAX_PROCS; i++) {
       memset( &procTab[ i ], 0, sizeof( pcb_t ) ); 
        procTab[ i ].pid      = i;
        procTab[ i ].status   = STATUS_TERMINATED;
        procTab[ i ].tos      = ( uint32_t )( &tos_procs ) - ((i-1) * 0x00001000);
        procTab[ i ].ctx.cpsr = 0x50;
        procTab[ i ].ctx.sp   = procTab[ i ].tos;
        procTab[ i ].precedence = 1;
        procTab[ i ].age = 0;

   }
    
    dispatch(ctx, NULL, &procTab[0]);

  TIMER0->Timer1Load  = 0x00100000; // select period = 2^20 ticks ~= 1 sec
  TIMER0->Timer1Ctrl  = 0x00000002; // select 32-bit   timer
  TIMER0->Timer1Ctrl |= 0x00000040; // select periodic timer
  TIMER0->Timer1Ctrl |= 0x00000020; // enable          timer interrupt
  TIMER0->Timer1Ctrl |= 0x00000080; // enable          timer

  GICC0->PMR          = 0x000000F0; // unmask all            interrupts
  GICD0->ISENABLER1  |= 0x00000010; // enable timer          interrupt
  GICC0->CTLR         = 0x00000001; // enable GIC interface
  GICD0->CTLR         = 0x00000001; // enable GIC distributor

  int_enable_irq();
    
    
  return;
}

void hilevel_handler_svc( ctx_t* ctx, uint32_t id ) { 
  /* Based on the identifier (i.e., the immediate operand) extracted from the
   * svc instruction, 
   *
   * - read  the arguments from preserved usr mode registers,
   * - perform whatever is appropriate for this system call, then
   * - write any return value back to preserved usr mode registers.
   */

  switch( id ) {
    case 0x00 : { // 0x00 => yield()
      schedule( ctx );

      break;
    }

    case 0x01 : { // 0x01 => write( fd, x, n )
      int   fd = ( int   )( ctx->gpr[ 0 ] );  
      char*  x = ( char* )( ctx->gpr[ 1 ] );  
      int    n = ( int   )( ctx->gpr[ 2 ] ); 

      for( int i = 0; i < n; i++ ) {
        PL011_putc( UART0, *x++, true );
      }
      
      ctx->gpr[ 0 ] = n;

      break;
    }

    case 0x03 : {  // 0x03 => fork()
        pcb_t* child = make_child(executing, ctx);
        if (child == NULL) {                        // No available empty PCB's. Return -1
            PL011_putc( UART0, 'N', true );
            PL011_putc( UART0, 'U', true );
            PL011_putc( UART0, 'L', true );
            PL011_putc( UART0, 'L', true );
            ctx->gpr[ 0 ] = -1;     
            break;
        }
        ctx->gpr[ 0 ] = child->pid;
        child->ctx.gpr[ 0 ] = 0;
        procTab[ 0 ].precedence++;
        break;
    }

    case 0x04 : {   // 0x04 => exit(x)
        PL011_putc( UART0, 'E', true );
        PL011_putc( UART0, 'X', true );
        PL011_putc( UART0, 'I', true );
        PL011_putc( UART0, 'T', true );
        executing->status = STATUS_TERMINATED;
        schedule(ctx);
        procTab[ 0 ].precedence --;
        break;        

    }

    case 0x05: {    // 0x05 => exec(x)
        PL011_putc( UART0, 'E', true );
        PL011_putc( UART0, 'X', true );
        PL011_putc( UART0, 'E', true );
        PL011_putc( UART0, 'C', true );
        const void* x = (const void*) (ctx->gpr[ 0 ]);
        ctx->pc = (const void*) x;
        break;

    }

    case 0x06: {    // 0x06 => kill(pid, x)
        PL011_putc( UART0, 'K', true );
        PL011_putc( UART0, 'I', true );
        PL011_putc( UART0, 'L', true );
        PL011_putc( UART0, 'L', true );       
        int pid = ( int ) ctx->gpr[ 0 ];
        int x   = ( int ) ctx->gpr[ 1 ];
        for (int i = 0; i < MAX_PROCS; i++) {
            if (procTab[ i ].pid == pid) {
                procTab[ i ].status = STATUS_TERMINATED;
                procTab [ 0 ].precedence--; 
                break;
            }
        }
        break;
    }


    default   : { // 0x?? => unknown/unsupported
      break;
    }
  }

  return;
}
void hilevel_handler_irq(ctx_t* ctx) {
  // Step 2: read  the interrupt identifier so we know the source.

  uint32_t id = GICC0->IAR;

  // Step 4: handle the interrupt, then clear (or reset) the source.

  if( id == GIC_SOURCE_TIMER0 ) {
    PL011_putc( UART0, '[', true ); TIMER0->Timer1IntClr = 0x01;
    PL011_putc( UART0, 'T', true ); TIMER0->Timer1IntClr = 0x01;
    PL011_putc( UART0, 'I', true ); TIMER0->Timer1IntClr = 0x01;
    PL011_putc( UART0, 'M', true ); TIMER0->Timer1IntClr = 0x01;
    PL011_putc( UART0, 'E', true ); TIMER0->Timer1IntClr = 0x01;
    PL011_putc( UART0, 'R', true ); TIMER0->Timer1IntClr = 0x01;
    PL011_putc( UART0, ']', true ); TIMER0->Timer1IntClr = 0x01;
    schedule( ctx );
  }

  // Step 5: write the interrupt identifier to signal we're done.

  GICC0->EOIR = id;

  return;
}
